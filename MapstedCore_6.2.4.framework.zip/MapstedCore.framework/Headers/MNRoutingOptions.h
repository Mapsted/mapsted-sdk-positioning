//
//  MNRoutingOptions.h
//  positioning
//
//  Created by Parth Bhatt on 12/05/25.
//  Copyright © 2025 Mapsted. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MNIndoorOutdoorRouteOptions.h"

@interface MNRoutingOptions : NSObject

/**
 This boolean suggests whether routing via Ramps is enabled or disabled.
 */
@property (nonatomic, readonly) BOOL includeRamps;

/**
 This boolean suggests whether routing via Stairs is enabled or disabled.
 */
@property (nonatomic, readonly) BOOL includeStairs;

/**
 This boolean suggests whether routing via Escalators is enabled or disabled.
 */
@property (nonatomic, readonly) BOOL includeEscalators;

/**
 This boolean suggests whether routing via Elevators is enabled or disabled.
 */
@property (nonatomic, readonly) BOOL includeElevators;

/**
 This boolean suggests whether optimizeItinerary is enabled or disabled.
 */
@property (nonatomic, readonly) BOOL optimizeItinerary;

/**
 This boolean suggests whether accessiblilty is enabled or disabled.
 */
@property (nonatomic, readonly) BOOL isAccessible;

/**
 */
@property (nonatomic, readonly) BOOL hasLevelTransitionRestrictions;

@property (nonatomic, readonly) MNIndoorOutdoorRouteOptions *indoorOutdoorRouteOptions;

/// Creates an instance of `MNRoutingOptions`
/// - Parameter includeRamps: This is routing option to enable or disable routing via Ramps
/// - Parameter includeStairs: This is routing option to enable or disable routing via Stairs
/// - Parameter includeEscalators: This is routing option to enable or disable routing via Escalator
/// - Parameter includeElevators: This is routing option to enable or disable routing via Elevators
/// - Parameter optimizeItinerary: This is routing option to enable or disable optimize itineriary. In this case, sequence of destinations may change to decrease the travel time or make it more optimized.
/// - Parameter indoorOutdoorRouteOptions: This is indoor outdoor route options.
/// - Returns: The new `MNRoutingOptions`
- (nonnull MNRoutingOptions *)initWithIncludeRamps:(BOOL)includeRamps includeStairs:(BOOL)includeStairs includeEscalators:(BOOL)includeEscalators includeElevators:(BOOL)includeElevators optimizeItinerary:(BOOL)optimizeItinerary indoorOutdoorRouteOptions:(MNIndoorOutdoorRouteOptions *)indoorOutdoorRouteOptions;

/// Creates an default instance of `MNRoutingOptions`. The default instance will have all the `includeRamps`, `includeStairs`, `includeEscalators` and `includeElevators` enabled
/// - Returns: The new `MNRoutingOptions`
+ (nonnull MNRoutingOptions *)defaultInstance;

/// Creates an acessible instance of `MNRoutingOptions` with options to set the `optimizeItinerary` and `emergency` options
/// - Parameter optimizeItinerary: This is routing option to enable or disable optimize itineriary. In this case, sequence of destinations may change to decrease the travel time or make it more optimized.
/// - Returns: The new `MNRoutingOptions`
+ (nonnull MNRoutingOptions *)accessibleInstanceWithOptimizeItinerary:(BOOL)optimizeItinerary;


/// Creates an instance which will by pass all level transitions options of `MNRoutingOptions` with options to set the `optimizeItinerary` and `emergency` options
/// - Parameter optimizeItinerary: This is routing option to enable or disable optimize itineriary. In this case, sequence of destinations may change to decrease the travel time or make it more optimized.
/// - Returns: The new `MNRoutingOptions`
+ (nonnull MNRoutingOptions *)bypassLevelTransitionsOptionsInstanceWithOptimizeItinerary:(BOOL)optimizeItinerary;

@end

//Builder
@interface MNRoutingOptionsBuilder : NSObject

- (nonnull MNRoutingOptionsBuilder *)setIncludeRamps:(BOOL)value;
- (nonnull MNRoutingOptionsBuilder *)setIncludeStairs:(BOOL)value;
- (nonnull MNRoutingOptionsBuilder *)setIncludeEscalators:(BOOL)value;
- (nonnull MNRoutingOptionsBuilder *)setIncludeElevators:(BOOL)value;
- (nonnull MNRoutingOptionsBuilder *)setItineraryOptimization:(BOOL)value;
- (nonnull MNRoutingOptionsBuilder *)setIndoorOutdoorOptions:(nullable MNIndoorOutdoorRouteOptions *)indoorOutdoorRouteOptions;

- (nonnull MNRoutingOptions *)build;

@end
