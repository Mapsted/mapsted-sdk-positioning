//
//  MNRoleAccessPair.h
//  positioning
//
//  Created by Pooja Trivedi on 17/06/25.
//  Copyright © 2025 Mapsted. All rights reserved.
//

// MNRoleAccessPair.h
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MNRoleAccessPair : NSObject

@property (nonatomic, strong) NSString *roleId;
@property (nonatomic, strong) NSString *accessLevelId;

- (instancetype)initWithRoleId:(NSString *)roleId accessLevelId:(NSString *)accessLevelId;

@end

NS_ASSUME_NONNULL_END

