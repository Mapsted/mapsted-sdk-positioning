//
//  MNRouteRequest.h
//  positioning
//
//  Created by Tianyun Shan on 2019-04-05.
//  Copyright © 2019 Mapsted. All rights reserved.
//

#ifndef MNRouteRequest_h
#define MNRouteRequest_h

@protocol Searchable;
@class MNRoutingOptions;
@class MNRoutingConstraints;
/***************************************************************************/

/// Represents a route request

@interface MNRouteRequest : NSObject

/***************************************************************************/

/**
 This is propertyId provided as a part of route request
 */
@property (nonatomic, readonly) NSInteger propertyId;

/**
 This is start waypoint for the route request
 */
@property (nonatomic, strong, readonly, nullable) id<Searchable> startWaypoint;

/**
 This is list of destination waypoints for the route request
 */
@property (nonatomic, strong, readonly, nonnull) NSArray<Searchable> *destinationWaypoints;

/**
 This is route options for the route request
 */
@property (nonatomic, strong, readonly, nonnull) MNRoutingOptions *routingOptions;

/**
 This is boolean which is passed in the route request to inform whether route starts from current location
 */
@property (nonatomic, readonly) BOOL isFromCurrentLocation;

/**
 This is routing constraints object which contains information of alerts, etc for the route request current location
 */
@property (nonatomic, strong, readonly, nullable) MNRoutingConstraints *routingConstraints;

/// Creates an instance of 'MNRouteRequest' with the specified 'routeOptions', possibly 'fromCurrentLocation', towards possibly multiple 'destinations' beginning from location specified by 'startEntity'
///
/// - Parameter routeOptions:  What options to use in creating the route
/// - Parameter fromCurrentLocation: Whether or not the routing should start from present location
/// - Parameter destinations: One or more destinations for the route
/// - Parameter startEntity: The entity from which the route will begin

- (nonnull MNRouteRequest *)initWithPropertyId:(NSInteger)propertyId
                    startWaypoint:(nullable id<Searchable>)startWaypoint
            destinationWaypoints:(nonnull NSArray<Searchable> *)destinationWaypoints
                  routingOptions:(nonnull MNRoutingOptions *)routingOptions
              routingConstraints:(nullable MNRoutingConstraints *)routingConstraints
           isFromCurrentLocation:(BOOL)isFromCurrentLocation;
/***************************************************************************/
@end

@interface MNRouteRequestBuilder : NSObject

- (nonnull id)initWithPropertyId:(NSInteger)propertyId;

- (nonnull MNRouteRequestBuilder *)setStartWaypoint:(nullable id<Searchable>)waypoint;
- (nonnull MNRouteRequestBuilder *)addDestinationWaypoint:(nonnull id<Searchable>)waypoint;
- (nonnull MNRouteRequestBuilder *)setRoutingOptions:(nonnull MNRoutingOptions *)options;
- (nonnull MNRouteRequestBuilder *)setRoutingConstraints:(nonnull MNRoutingConstraints *)constraints;
- (nonnull MNRouteRequestBuilder *)setIsFromCurrentLocation:(BOOL)isFromCurrentLocation;
- (nonnull MNRouteRequestBuilder *)setDestinationWaypoints:(nonnull NSMutableArray<Searchable> *)waypoints;
- (nonnull MNRouteRequest *)build;

@end

/***************************************************************************/

#endif /* MNRouteRequest_h */
