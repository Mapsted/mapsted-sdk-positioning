//
//  MapPackageManagerWrapper.h
//  MapViewer
//
//  Created by Mapsted on 2019-02-01.
//  Copyright © 2019 Mapsted. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MNPackageStatus.h"

NS_ASSUME_NONNULL_BEGIN

@interface MapPackageManagerWrapper : NSObject

+ (nonnull instancetype)shared;

- (void)mergePackage:(NSString *) packagePath forPropertyId:(int)propertyId;
- (void)updatePackage:(int) propertyId withPackageStatus:(MNPackageStatus)status;
- (void)setBaseMapLayer:(NSString *)path;
- (MNPackageStatus)getPackageStatus:(int)propertyId;
@end

NS_ASSUME_NONNULL_END
