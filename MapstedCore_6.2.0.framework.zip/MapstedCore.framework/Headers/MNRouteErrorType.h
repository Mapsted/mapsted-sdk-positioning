//
//  MNRouteErrorType.h
//  positioning
//
//  Created by Parth Bhatt on 07/05/25.
//  Copyright © 2025 Mapsted. All rights reserved.
//

#ifndef MNRouteErrorType_h
#define MNRouteErrorType_h

typedef NS_ENUM(NSInteger, MNRouteErrorType) {
    Success,
    InvalidRequest,
    StartInvalid,
    StartNoNode,
    DestinationInvalid,
    DestinationNoNode,
    PropertyDataUnavailable,
    BuildingDataUnavailable,
    AlertBlockingRoute,
    ImpossibleRoute,
    Miscellaneous,
    NoRoutingPermissions,
    UnknownUserLocationInWayfindingMode,
    UnknownUserLocationInPositioningMode,
    NullInternals,
    ImpossibleRouteViaTransitionsOptions
};

#endif
