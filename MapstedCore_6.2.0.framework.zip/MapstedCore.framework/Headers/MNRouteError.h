//
//  MNRouteError.h
//  positioning
//
//  Created by Parth Bhatt on 07/05/25.
//  Copyright © 2025 Mapsted. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, MNRouteErrorType);

#ifndef MNRouteError_h
#define MNRouteError_h

@interface MNRouteError : NSObject

/**
  This boolean suggests whether the route response is successful or not.
 */
@property (readonly) BOOL isSuccessful;

/**
  The errorType is an enum which suggest which is the type of the error.
 */
@property (readonly) MNRouteErrorType errorType;

/**
  The errorMessage is a string which contains the error message.
 */
@property (readonly, nullable) NSString *errorMessage;

/**
  The errorTypeDescription is a error description based on type of error.
 */
@property (readonly, nonnull) NSString *errorTypeDescription;

/// Creates an instance of 'MNRouteError' with a specified 'errorMessage' and 'errorType'
/// - Parameter errorMessage: This is a string which contains the error message.
/// - Parameter errorType: This is an enum which suggest which is the type of the error
/// - Parameter isSuccess:  This boolean is used to suggest whether this is successful or error response.
/// - Returns: The new `MNRouteError` instance.
- (nonnull MNRouteError *)initWithError:(NSString * _Nullable)errorMessage type:(MNRouteErrorType)errorType isSuccess:(BOOL)isSuccess;

/// Sets the error type description string parameter based on error type enum
/// - Parameter error: This is enum which suggest which is the type of the error
-(void)setErrorTypeDescription:(MNRouteErrorType)error;

-(nullable NSString *)description;

@end

#endif //MNRouteError_h
