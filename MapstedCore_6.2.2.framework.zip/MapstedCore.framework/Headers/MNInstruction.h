//
//  MNInstruction.h
//  positioning
//
//  Created by Parth Bhatt on 07/05/25.
//  Copyright © 2025 Mapsted. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger, MNInstructionType);

@interface MNInstruction : NSObject

/**
 This is enum that has instruction type.
 */
@property (nonatomic, readonly) MNInstructionType instructionType;

/**
 This is instruction text
 */
@property (nonatomic, copy, readonly, nullable) NSString *text;

/**
 This is image for the instruction.
 */
@property (nonatomic, assign, readonly, nullable) UIImage *image;

/// Creates an instance of `MNInstruction` with 'instructionType', 'text' and 'image'.
/// - Parameter instructionType: This is instruction type parameter
/// - Parameter image: This is image for the instruction
/// - Returns: The new `MNInstruction` with 'instructionType', 'text' and 'image'.
- (nonnull MNInstruction *)initWithInstructionType:(MNInstructionType)instructionType text:(NSString * _Nullable)text image:(UIImage * _Nullable)image;

@end
