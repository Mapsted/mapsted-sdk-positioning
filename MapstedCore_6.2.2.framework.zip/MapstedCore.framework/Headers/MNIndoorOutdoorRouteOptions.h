//
//  MNIndoorOutdoorRouteOptions.h
//  positioning
//
//  Created by Parth Bhatt on 20/08/25.
//  Copyright © 2025 Mapsted. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MNIndoorOutdoorRouteOptions : NSObject

/**
 This boolean suggests whether accessible entrance is enabled or disabled.
 */
@property (nonatomic, readonly) BOOL accessibleEntrance;

/**
 This boolean suggests whether prefer indoor route is enabled or disabled.
 */
@property (nonatomic, readonly) BOOL preferIndoorRoute;

/**
 This boolean suggests whether prefer outdoor route is enabled or disabled.
 */
@property (nonatomic, readonly) BOOL preferOutdoorRoute;

/**
 This boolean suggests whether include primary entrance is enabled or disabled.
 */
@property (nonatomic, readonly) BOOL includePrimaryEntrance;

/**
 This boolean suggests whether include secondary entrance is enabled or disabled.
 */
@property (nonatomic, readonly) BOOL includeSecondaryEntrance;

/**
 This boolean suggests whether include building to building entrance is enabled or disabled.
 */
@property (nonatomic, readonly) BOOL includeBuildingToBuildingEntrance;

/**
 This boolean suggests whether include emergency entrance is enabled or disabled.
 */
@property (nonatomic, readonly) BOOL includeEmergencyEntrance;

/**
 This boolean suggests whether include restricted entrance is enabled or disabled.
 */
@property (nonatomic, readonly) BOOL includeRestrictedEntrance;

/// Creates an instance of `MNIndoorOutdoorRouteOptions`
/// - Parameter accessibleEntrance: This is routing option to enable or disable accessible entrance
/// - Parameter preferIndoorRoute: This is routing option to enable or disable prefer indoor route
/// - Parameter preferOutdoorRoute: This is routing option to enable or disable prefer outdoor route
/// - Parameter includePrimaryEntrance: This is routing option to enable or disable include primary entrance
/// - Parameter includeSecondaryEntrance: This is routing option to enable or disable include secondary entrance
/// - Parameter includeBuildingToBuildingEntrance: This is routing option to enable or disable include building to building entrance
/// - Parameter includeEmergencyEntrance: This is routing option to enable or disable include emergency entrance
/// - Parameter includeRestrictedEntrance: This is routing option to enable or disable include restricted entrance
/// - Returns: The new `MNIndoorOutdoorRouteOptions`
- (nonnull MNIndoorOutdoorRouteOptions *)initWithAccessibleEntrance:(BOOL)accessibleEntrance preferIndoorRoute:(BOOL)preferIndoorRoute preferOutdoorRoute:(BOOL)preferOutdoorRoute includePrimaryEntrance:(BOOL)includePrimaryEntrance includeSecondaryEntrance:(BOOL)includeSecondaryEntrance includeBuildingToBuildingEntrance:(BOOL)includeBuildingToBuildingEntrance includeEmergencyEntrance:(BOOL)includeEmergencyEntrance includeRestrictedEntrance:(BOOL)includeRestrictedEntrance;

/// Creates an default instance of `MNIndoorOutdoorRouteOptions`.
/// - Returns: The new `MNIndoorOutdoorRouteOptions`
+ (nonnull MNIndoorOutdoorRouteOptions *)defaultInstance;

@end

//Builder
@interface MNIndoorOutdoorRouteOptionsBuilder : NSObject

- (nonnull MNIndoorOutdoorRouteOptionsBuilder *)setAccessibleEntrance:(BOOL)value;
- (nonnull MNIndoorOutdoorRouteOptionsBuilder *)setPreferIndoorRoute:(BOOL)value;
- (nonnull MNIndoorOutdoorRouteOptionsBuilder *)setPreferOutdoorRoute:(BOOL)value;
- (nonnull MNIndoorOutdoorRouteOptionsBuilder *)setIncludePrimaryEntrance:(BOOL)value;
- (nonnull MNIndoorOutdoorRouteOptionsBuilder *)setIncludeSecondaryEntrance:(BOOL)value;
- (nonnull MNIndoorOutdoorRouteOptionsBuilder *)setIncludeBuildingToBuildingEntrance:(BOOL)value;
- (nonnull MNIndoorOutdoorRouteOptionsBuilder *)setIncludeEmergencyEntrance:(BOOL)value;
- (nonnull MNIndoorOutdoorRouteOptionsBuilder *)setIncludeRestrictedEntrance:(BOOL)value;

- (nonnull MNIndoorOutdoorRouteOptions *)build;

@end
