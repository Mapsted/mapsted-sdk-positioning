//
//  MNDataType.h
//  positioning
//
//  Created by Tianyun Shan on 2018-11-21.
//  Copyright © 2018 Mapsted. All rights reserved.
//

#ifndef MNPackageStatus_h
#define MNPackageStatus_h


/// Represents data types (Property, Building, etc)
typedef NS_ENUM(NSInteger, MNPackageStatus) {
    MNPackageStatusUnknown,
    MNPackageStatusInProgress,
    MNPackageStatusFailed,
    MNPackageStatusDownloaded
};

#endif /* MNPackageStatus_h */
