//
//  MNNavigationError.h
//  positioning
//
//  Created by Parth Bhatt on 14/05/25.
//  Copyright © 2025 Mapsted. All rights reserved.
//

#import <Foundation/Foundation.h>


typedef NS_ENUM(NSInteger, MNNavigationErrorType);

#ifndef MNNavigationError_h
#define MNNavigationError_h

@interface MNNavigationError : NSObject

/**
 The boolean which signifies whether the navigation is sucessfully started or not.
 */
@property (readonly) BOOL isSuccessful;

/**
 The error type enum show what is the kind of error in navigation. Enum type is MNNavigationErrorType.
 */
@property (readonly) MNNavigationErrorType errorType;

/**
 The error message string associated with the NavigationError.
 */
@property (readonly, nullable) NSString *errorMessage;

/**
 The error description string based on the errorType associated with the NavigationError.
 */
@property (readonly, nonnull) NSString *errorTypeDescription;

/// Creates an instance of `MNNavigationError`.
/// - Parameter errorMessage: The error message string associated with the NavigationError.
/// - Parameter errorType: The error type enum show what is the kind of error in navigation. Enum type is MNNavigationErrorType.
/// - Parameter isSuccess: The boolean which signifies whether the navigation is sucessfully started or not.
/// - Returns: instance of `MNNavigationError`.
- (nonnull MNNavigationError *)initWithError:(NSString * _Nullable)errorMessage type:(MNNavigationErrorType)errorType isSuccess:(BOOL)isSuccess;

/// Sets the error description based on the type of error
/// - Parameter error: The error type enum show what is the kind of error in navigation. Enum type is MNNavigationErrorType.
-(void)setErrorTypeDescription:(MNNavigationErrorType)error;

-(NSString * _Nonnull)description;

@end

#endif
