//
//  MapstedCore.h
//  MapstedCore
//
//  Created by Parth Bhatt on 20/01/24.
//

#import <Foundation/Foundation.h>

//! Project version number for MapstedCore.
FOUNDATION_EXPORT double MapstedCoreVersionNumber;

//! Project version string for MapstedCore.
FOUNDATION_EXPORT const unsigned char MapstedCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MapstedCore/PublicHeader.h>


#import "MapstedCore/MNMapstedLib.h"
#import "MapstedCore/MNGPSLoc.h"
#import "MapstedCore/MNWifiDataBridge.h"
#import "MapstedCore/MNBleDataBridge.h"
#import "MapstedCore/MNObjcUnitUtils.h"
#import "MapstedCore/MNMercator.h"
#import "MapstedCore/MNMercatorBoundary.h"
#import "MapstedCore/MNMercatorLoc.h"
#import "MapstedCore/MNMercatorZone.h"
#import "MapstedCore/MNLatLng.h"
#import "MapstedCore/MNTrajectory.h"
#import "MapstedCore/MNPolygonHighlight.h"
#import "MapstedCore/MNMapstedTestingKey.h"
#import "MapstedCore/MNSDKPermissions.h"
#import "MapstedCore/MapPackageManagerWrapper.h"
#import "MapstedCore/MNPermissionType.h"
#import "MapstedCore/SafeHandler.h"

// New Model

// Enum
#import "MapstedCore/MNDataType.h"
#import "MapstedCore/MNMapPerspective.h"
#import "MapstedCore/MNLanguageType.h"
#import "MapstedCore/MNZoneType.h"
#import "MapstedCore/MNIdType.h"
#import "MapstedCore/MNContentType.h"
#import "MapstedCore/MNEvent.h"
#import "MapstedCore/MNPositioningMode.h"
#import "MapstedCore/EnumSensorType.h"
#import "MapstedCore/EnumSdkMode.h"
#import "MapstedCore/EnumSdkError.h"
#import "MapstedCore/EnumSdkUpdate.h"
#import "MapstedCore/EnumValidBlueDotError.h"
#import "MapstedCore/MNPackageType.h"
#import "MapstedCore/MNPackageStatus.h"
#import "MapstedCore/MNConfidence.h"
#import "MapstedCore/StatusMessageType.h"
#import "MapstedCore/MNRouteSegmentType.h"
#import "MapstedCore/MNNavigationErrorType.h"
#import "MapstedCore/MNRoutePathType.h"
#import "MapstedCore/MNRouteErrorType.h"
#import "MapstedCore/MNInstructionType.h"

// Positioning
#import "MapstedCore/MNPosition.h"
#import "MapstedCore/MNZone.h"
#import "MapstedCore/MNPbZone.h"

// Style
#import "MapstedCore/MNColour.h"
#import "MapstedCore/MNLineStyle.h"
#import "MapstedCore/MNTextStyle.h"
#import "MapstedCore/MNIconStyle.h"
#import "MapstedCore/MNPolygonStyle.h"
#import "MapstedCore/MNPointStyle.h"
#import "MapstedCore/MNLayerStyle.h"

// General
#import "MapstedCore/MNObjectDataMap.h"
#import "MapstedCore/MNMapPolygon.h"
#import "MapstedCore/MNMapPolyline.h"
#import "MapstedCore/MNMapPoint.h"
#import "MapstedCore/MNSearchEntity.h"
#import "MapstedCore/MNZoneLabel.h"
#import "MapstedCore/MNPropertySearchFilters.h"
#import "MapstedCore/MNMapEntity.h"
#import "MapstedCore/MNEntityZone.h"

// Building
#import "MapstedCore/MNParsedBuildingDataResponse.h"
#import "MapstedCore/MNParsedBuildingDataItem.h"
#import "MapstedCore/MNParsedBuildingLanguageDataItem.h"
#import "MapstedCore/MNBuildingInfo.h"
#import "MapstedCore/MNFloorInfo.h"
#import "MapstedCore/MNBuildingData.h"
#import "MapstedCore/MNBuildingEntities.h"
#import "MapstedCore/MNBuildingPolygons.h"
#import "MapstedCore/MNBuildingPolylines.h"
#import "MapstedCore/MNBuildingPoints.h"
#import "MapstedCore/MNBuildingSearchEntities.h"

// Category

#import "MapstedCore/MNParsedPropertyListAndCategoryResponse.h"

// Marketing
#import "MapstedCore/MNParsedContentResponse.h"

// Property
#import "MapstedCore/MNPropertyInfo.h"
#import "MapstedCore/MNParsedPropertyDataResponse.h"
#import "MapstedCore/MNParsedPropertyDataItem.h"
#import "MapstedCore/MNParsedPropertyLanguageDataItem.h"
#import "MapstedCore/MNPropertyData.h"
#import "MapstedCore/MNPropertyEntities.h"
#import "MapstedCore/MNPropertyPolygons.h"
#import "MapstedCore/MNPropertyPolylines.h"
#import "MapstedCore/MNPropertyPoints.h"
#import "MapstedCore/MNDailyBusinessHour.h"
#import "MapstedCore/MNHoursOfOperation.h"
#import "MapstedCore/MNPropertySearchEntities.h"

//Routing
#import "MapstedCore/MNRouteRequest.h"
#import "MapstedCore/MNRouteResponse.h"
#import "MapstedCore/MNRoute.h"
#import "MapstedCore/MNRegion.h"
#import "MapstedCore/MNDistanceTime.h"
#import "MapstedCore/MNRouteError.h"
#import "MapstedCore/MNRoutePathSegment.h"
#import "MapstedCore/MNRoutePath.h"
#import "MapstedCore/MNRoutePointInstruction.h"
#import "MapstedCore/MNRoutingConstraints.h"
#import "MapstedCore/MNRoutingOptions.h"
#import "MapstedCore/MNIndoorOutdoorRouteOptions.h"
#import "MapstedCore/MNInstruction.h"

//Navigation
#import "MapstedCore/MNNavigationError.h"
#import "MapstedCore/MNNavigationState.h"

//Tag
#import "MapstedCore/MNTag.h"

//Analytics
#import "MapstedCore/MapstedAnalyticsApi.h"
#import "MapstedCore/MNAnalyticsBundle.h"
#import "MapstedCore/MapstedAnalyticsManager.h"

//Triggers
#import "MapstedCore/CppGeofenceTriggerBuilder.h"
#import "MapstedCore/CppBuildingLocationCriteria.h"
#import "MapstedCore/CppFloorLocationCriteria.h"
#import "MapstedCore/CppPoiVicinityLocationCriteria.h"
#import "MapstedCore/CppPropertyLocationCriteria.h"
#import "MapstedCore/EnumLocationCriteriaTriggerDirection.h"
#import "MapstedCore/EnumLocationCriteriaTriggerType.h"
#import "MapstedCore/ICppLocationCriteria.h"
#import "MapstedCore/MNUserLocationManager.h"
#import "MapstedCore/LocationServicesCallback.h"
//#import "MapstedCore/MapstedCore-Swift.h"
