//
//  MNRoutePointInstruction.h
//  positioning
//
//  Created by Parth Bhatt on 07/05/25.
//  Copyright © 2025 Mapsted. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@class MNInstruction;
@class MNMercatorZone;
@class MNDistanceTime;
@class MNZone;
@class MNMercator;
@class MNInstruction;

typedef NS_ENUM(NSInteger, MNInstructionType);

@interface MNRoutePointInstruction : NSObject
/**
 This is  language string for the given route point instruction
 */
@property (nonatomic, strong) NSString *language;
/**
 This is instruction type enum for the given route point instruction
 */
@property (nonatomic, readonly) MNInstructionType instructionType;

/**
 This is array of landmark entity ids for the given route point instruction
 */
@property (nonatomic, readonly, nonnull) NSArray<NSNumber *> *landmarkEntityIds;

/**
 This is array of enter alert ids for the given route point instruction
 */
@property (nonatomic, readonly, nonnull) NSArray<NSString *> *enterAlertIds;

/**
 This is array of exit alert ids for the given route point instruction
 */
@property (nonatomic, readonly, nonnull) NSArray<NSString *> *exitAlertIds;

/**
 This is mercator zone for the given route point instruction
 */
@property (nonatomic, readonly, nullable) MNMercatorZone *point;

/**
 */
@property (readonly) BOOL isAccessible;

/**
 This is transition zone for the given route point instruction
 */
@property (nonatomic, readonly, nullable) MNZone *transitionZone;

/**
 This is zone for the given route point instruction
 */
@property (nonatomic, readonly, nullable) MNZone *zone;

/**
 This is pre map rotation angle in radians
 */
@property (readonly) float preMapRotationRad;

/**
 This is post map rotation angle in radians
 */
@property (readonly) float postMapRotationRad;

/**
 */
@property (readonly) NSInteger pointIdx;

/**
 */
@property (readonly) NSInteger segmentIdx;

/**
 */
@property (nonatomic, readonly, nullable) MNMercator *mercator;

/**
 This is distance time to the next instruction
 */
@property (nonatomic, readonly, nullable) MNDistanceTime *toNextInstructionDistanceTime;


- (nonnull MNRoutePointInstruction *)initWithInstructionType: (MNInstructionType)instructionType pointIdx:(NSInteger)pointIdx landmarkEntityIds: (NSArray<NSNumber *> * _Nonnull)landmarkEntityIds enterAlertIds: (NSArray<NSString*> * _Nonnull)enterAlertIds exitAlertIds:(NSArray<NSString*> * _Nonnull)exitAlertIds isAccessible:(BOOL)isAccessible toNextInstructionDistanceTime:(MNDistanceTime * _Nullable)toNextInstructionDistanceTime transitionZone:(MNZone * _Nullable)transitionZone preMapRotationRad:(float)preMapRotationRad postMapRotationRad:(float)postMapRotationRad segmentIdx:(NSInteger)segmentIdx mercator:(MNMercator * _Nullable)mercator mercatorZone:(MNMercatorZone * _Nullable)mercatorZone zone:(MNZone * _Nullable)zone;

- (NSInteger)pointIdx;
- (float)getPreMapRotationDeg;
- (float)getPostMapRotationDeg;
- (BOOL)isLevelTransitionInstruction;
- (BOOL)isBuildingTransitionInstruction;
//- (MNInstruction * _Nullable)getInstruction;

//- (MNInstruction *)buildTransitionInstructionWithBaseKey:(NSString *)baseKey transitionKey:(NSString *)transitionKey landmarkKey:(NSString *)landmarkKey image:(UIImage *)image;

//- (nullable NSString *)getEntityLandmarkName;


@end

